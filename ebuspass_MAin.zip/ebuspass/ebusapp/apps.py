from django.apps import AppConfig


class EbusappConfig(AppConfig):
    name = 'ebusapp'
